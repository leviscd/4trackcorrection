// --- Theme Toggle ---
const themeToggleBtn = document.getElementById('theme-toggle');
const htmlElement = document.documentElement;

themeToggleBtn.addEventListener('click', () => {
    htmlElement.classList.toggle('dark');
    localStorage.setItem('theme', htmlElement.classList.contains('dark') ? 'dark' : 'light');
    lucide.createIcons();
});

// Load saved theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'light') htmlElement.classList.remove('dark');
else htmlElement.classList.add('dark');

// --- Mobile Menu Toggle ---
const mobileMenuBtn = document.getElementById('mobile-menu-btn');
const mobileMenu = document.getElementById('mobile-menu');

mobileMenuBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
});

// --- Modules Rendering ---
const modules = [
    { title: "Consulta CPF", icon: "fingerprint", desc: "Dados cadastrais completos via CPF.", badge: "2 Fontes" },
    { title: "Consulta CNPJ", icon: "building-2", desc: "Dados empresariais Receita Federal.", badge: "Receita" },
    { title: "Consulta Nome", icon: "user", desc: "Busca assertiva por nome completo.", badge: null },
    { title: "Consulta Telefone", icon: "phone", desc: "Vínculos de telefonia atualizados.", badge: null },
    { title: "Consulta Fotos", icon: "camera", desc: "Reconhecimento facial e arquivos.", badge: "10 Fontes" },
    { title: "Consulta Veicular", icon: "car", desc: "Histórico completo do veículo.", badge: "DETRAN" },
    { title: "Foto CNH", icon: "id-card", desc: "Foto base original CNH/DETRAN.", badge: null },
    { title: "Funcionários", icon: "users", desc: "Quadro societário e funcionários.", badge: null },
    { title: "Consulta Chassi", icon: "scan-barcode", desc: "Decodificação de chassi BIN.", badge: null },
    { title: "Consulta Renavam", icon: "bar-chart-3", desc: "Débitos e restrições Renavam.", badge: null },
    { title: "Consulta Motor", icon: "settings", desc: "Numeração e cadastro de motor.", badge: null },
    { title: "Radar Nacional", icon: "radar", desc: "Infrações em tempo real.", badge: "Novo" }
];

function renderModules() {
    const grid = document.getElementById('modules-grid');
    let html = '';
    modules.forEach(mod => {
        html += `<div class="glass-card group relative rounded-xl p-5 transition-all duration-300 hover:-translate-y-1 cursor-pointer overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div class="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-purple-500 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div class="relative z-10">
                <div class="flex justify-between items-start mb-4">
                    <div class="relative flex items-center justify-center w-12 h-12 rounded-lg bg-slate-100 dark:bg-purple-900/20 text-slate-600 dark:text-purple-400 border border-slate-200 dark:border-purple-500/30 group-hover:border-purple-500 group-hover:shadow-[0_0_15px_rgba(168,85,247,0.3)] transition-all duration-300">
                        <i data-lucide="${mod.icon}" class="w-6 h-6"></i>
                    </div>
                    ${mod.badge ? `<span class="inline-flex items-center px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider text-purple-600 bg-purple-100 dark:text-purple-200 dark:bg-purple-500/20 border border-purple-200 dark:border-purple-500/30 shadow-glow-sm">${mod.badge}</span>` : ''}
                </div>
                <h3 class="text-base font-bold text-slate-800 dark:text-slate-100 mb-1 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">${mod.title}</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-medium">${mod.desc}</p>
            </div>
        </div>`;
    });
    grid.innerHTML = html;
}

// --- Recent Queries ---
const recentQueries = [
    { status: 'success', value: '123.456.789-00', module: 'Consulta CPF', time: '14s ago' },
    { status: 'error', value: 'ABC-1234', module: 'Consulta Veicular', time: '42s ago' },
    { status: 'success', value: 'Carlos A. Silva', module: 'Consulta Nome', time: '2m ago' },
    { status: 'success', value: '(11) 99888-7777', module: 'Consulta Telefone', time: '5m ago' },
    { status: 'success', value: '45.123.001/0001-99', module: 'Consulta CNPJ', time: '12m ago' }
];

function renderRecentQueries() {
    const tbody = document.getElementById('recent-queries-body');
    let html = '';
    recentQueries.forEach((query, index) => {
        const statusDot = query.status === 'success'
            ? `<div class="flex items-center gap-2"><span class="relative flex h-2 w-2"><span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span><span class="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span></span><span class="text-xs font-bold text-green-600 dark:text-green-400 uppercase tracking-wider">RETORNADO</span></div>`
            : `<div class="flex items-center gap-2"><span class="relative flex h-2 w-2"><span class="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span></span><span class="text-xs font-bold text-red-600 dark:text-red-400 uppercase tracking-wider">ERRO</span></div>`;
        const bgClass = index % 2 === 0 ? 'bg-transparent' : 'bg-slate-50/50 dark:bg-white/[0.02]';
        html += `<tr class="${bgClass} hover:bg-purple-50 dark:hover:bg-purple-900/10 transition-colors">
            <td class="p-4 pl-6">${statusDot}</td>
            <td class="p-4"><span class="font-mono text-sm text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-black/30 px-2 py-1 rounded border border-slate-200 dark:border-white/10">${query.value}</span></td>
            <td class="p-4 text-sm font-medium text-slate-600 dark:text-slate-400">${query.module}</td>
            <td class="p-4 text-right pr-6 text-xs text-slate-400 font-mono">${query.time}</td>
        </tr>`;
    });
    tbody.innerHTML = html;
}

// --- Init ---
renderModules();
renderRecentQueries();
lucide.createIcons();
